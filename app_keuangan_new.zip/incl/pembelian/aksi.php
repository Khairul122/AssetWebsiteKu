<?php
if (empty($_GET['link'])) {
    $link = '';
} else {
    $link = $_GET['link'];
}
if (empty($_GET['aksi'])) {
    $aksi = '';
} else {
    $aksi = $_GET['aksi'];
}
switch ($link) {
    case 'tambah_pembelian':
        # code...
        $username = $_SESSION['username'];
        $no_faktur = $_POST['no_faktur'];
        $kd_barang = $_POST['kd_barang'];
        $jumlah_beli = $_POST['jumlah_beli'];
        $tgl_pembelian = date('Y-m-d');

        $queryambil = mysqli_query($conn, "select * from tb_barang where kd_barang='$kd_barang'");
        $ambil = mysqli_fetch_array($queryambil);
        $nm_barang = $ambil['nama_barang'];
        $harga = $ambil['harga_beli'];

        $cekquery = mysqli_query($conn, "select * from tb_pembelian where kd_barang='$kd_barang' and no_faktur='$no_faktur'");
        $ambilcek = mysqli_num_rows($cekquery);
        if ($ambilcek < 1) {
            $query = mysqli_query($conn, "insert into tb_pembelian values (null, '$no_faktur', '$tgl_pembelian','$kd_barang','$nm_barang','$harga','$jumlah_beli','Proses')");
            if ($query > 0) {
                header("Location: index.php?link=tambah_pembelian&pesan=Berhasil");
            } else {
                header("Location: index.php?link=tambah_pembelian&pesan=Gagal");
            }
        } else {
            $query = mysqli_query($conn, "update tb_pembelian set jumlah_beli=jumlah_beli+'$jumlah_beli' where kd_barang='$kd_barang' and no_faktur='$no_faktur'");
            if ($query > 0) {
                header("Location: index.php?link=tambah_pembelian&pesan=Berhasil");
            } else {
                header("Location: index.php?link=tambah_pembelian&pesan=Gagal");
            }
        }
        // echo $nomor_antrian;
        break;
    case 'hapus_pembelian':
        # code...
        $id_pembelian = $_GET['id_pembelian'];
        $query = mysqli_query($conn, "delete from tb_pembelian where id_pembelian='$id_pembelian'");
        if ($query > 0) {
            header("Location: index.php?link=pembelian");
        } else {
            header("Location: index.php?link=pembelian");
        }
        break;
    case 'hapus_pembelian_':
        # code...
        $id_pembelian = $_GET['id_pembelian'];
        $query = mysqli_query($conn, "delete from tb_pembelian where id_pembelian='$id_pembelian'");
        if ($query > 0) {
            header("Location: index.php?link=tambah_pembelian");
        } else {
            header("Location: index.php?link=tambah_pembelian");
        }
        break;
    case 'selesai_pembelian':
        # code...
        $no_faktur = $_GET['no_faktur'];
        $query = mysqli_query($conn, "update tb_pembelian set status='Selesai' where no_faktur='$no_faktur'");
        if ($query > 0) {
            header("Location: index.php?link=tambah_pembelian");
        } else {
            header("Location: index.php?link=tambah_pembelian");
        }
        break;

    default:
        # code...
        break;
}
?>