<?php
$username=$_SESSION['username'];
$query=mysqli_query($conn,"select * from tb_pembelian t1");
if (empty($_GET['pesan'])) {
  $pesan = '';
} else {
  $pesan = $_GET['pesan'];
}
?>
<!-- Begin Page Content -->
<div class="container-fluid">
            <!-- Content -->
            <div class="container flex-grow-1 container-p-y">
              <?php
                if($pesan=="Berhasil"){
                  ?>
                  <p class="alert alert-success"><?php echo $pesan ?></p>
                  <?php
                }else if($pesan=="Gagal"){
                  ?>
                  <p class="alert alert-danger"><?php echo $pesan ?></p>
                  <?php
                }
              ?>

              <!-- Basic Bootstrap Table -->
              <div class="card">
                <h5 class="card-header"><a href="index.php?link=tambah_pembelian" class="btn btn-primary btn-xs"><i class="menu-icon tf-icons bx bx-plus"></i> Pembelian</a></h5>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>No Faktur</th>
                        <th>Tanggal</th>
                        <th>Nama Barang</th>
                        <th>Harga</th>
                        <th>Jumlah Beli</th>
                        <th>Sub Harga</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php
                      $no=0;
                      while ($panggil=mysqli_fetch_array($query)) {
                        # code...
                        $no++;
                          $aksi="<a href='index.php?link=hapus_pembelian&id_pembelian=$panggil[id_pembelian]' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a>";
                          $subharga=$panggil['harga']*$panggil['jumlah_beli'];
                        echo "
                        <tr>
                          <td>$no</td>
                          <td>$panggil[no_faktur]</td>
                          <td>$panggil[tanggal]</td>
                          <td>$panggil[nm_barang]</td>
                          <td>$panggil[harga]</td>
                          <td>$panggil[jumlah_beli]</td>
                          <td>$subharga</td>
                          <td>$aksi</td>
                        </tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <!--/ Basic Bootstrap Table -->

            

              <hr class="my-5" />

             
            </div>
            <!-- / Content -->