<?php

$hari_in = hari_ini();
$tgl = date('Y-m-d');
$query = mysqli_query($conn, "SELECT max(no_faktur) as kodeTerbesar FROM tb_pembelian where date(tanggal)='$tgl' and status='Selesai'");
$data = mysqli_fetch_array($query);
$nomor_antrian = (int) substr($data['kodeTerbesar'], 3, 5);
$nomor_antrian++;
$char = "PMB";
$newID = $char . sprintf("%05s", $nomor_antrian);


$query_pembelian=mysqli_query($conn,"select * from tb_pembelian t1 where t1.no_faktur='$newID'");
?>
<!-- Begin Page Content -->
<div class="container-fluid">
  <!-- Content -->

  <div class="container flex-grow-1 container-p-y">
    <!-- Basic Layout & Basic with Icons -->
    <div class="row">
      <!-- Basic Layout -->
      <div class="col">
        <div class="card mb-4">
          <div class="card-header d-flex align-items-center justify-content-between">

          </div>
          <div class="card-body">
            <form action="index.php?link=tambah_pembelian&aksi=simpan" method="POST">
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-message">No Faktur</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" placeholder="No Faktur" name="no_faktur"
                    value="<?php echo $newID ?>" id="" readonly>
                </div>


                <label class="col-sm-2 col-form-label" for="basic-default-message">Tanggal</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" placeholder="Tanggal" name="tanggal"
                    value="<?php echo tgl_indo(date('Y-m-d')) ?>" id="" readonly>
                </div>
              </div>
              
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-company">Nama Barang</label>
                <div class="col-sm-2">
                  <select name="kd_barang" id="" class="form-control" id="basic-default-company" required>
                    <option value="">Pilih</option>
                    <?php
                    $query = mysqli_query($conn, "select * from tb_barang");
                    while ($data = mysqli_fetch_array($query)) {
                      # code...
                      ?>
                      <option value="<?php echo $data['kd_barang'] ?>">
                        <?php echo $data['nama_barang'] ?>
                      </option>
                      <?php
                    }
                    ?>
                  </select>
                </div>
                <label class="col-sm-2" for="">
                  <a href="index.php?link=tambah_barang" class="btn btn-primary btn-xs"><i
                      class='fas fa-plus'></i></a>
                </label>
                <label class="col-sm-2 col-form-label" for="basic-default-message">Jumlah Beli</label>
                <div class="col-sm-2">
                  <input type="number" class="form-control" placeholder="jumlah beli" name="jumlah_beli" id="" required>
                </div>
                <label class="col-sm-2" for="">
                  <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary"> Add</button>
                  </div>
                </label>
              </div>

              <div class="card">
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Harga</th>
                        <th>Jumlah Beli</th>
                        <th>Sub Harga</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php
                      $no=0;
                      while ($panggil=mysqli_fetch_array($query_pembelian)) {
                        # code...
                        $no++;
                          $aksi="<a href='index.php?link=hapus_pembelian_&id_pembelian=$panggil[id_pembelian]' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a>";
                          $subharga=$panggil['harga']*$panggil['jumlah_beli'];
                        echo "
                        <tr>
                          <td>$no</td>
                          <td>$panggil[nm_barang]</td>
                          <td>$panggil[harga]</td>
                          <td>$panggil[jumlah_beli]</td>
                          <td>$subharga</td>
                          <td>$aksi</td>
                        </tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>

              <div class="row justify-content-end">
                <div class="col-sm-10">
                  <a href="index.php?link=selesai_pembelian&no_faktur=<?php echo $newID ?>" class="btn btn-primary btn-xs"><i class='fas fa-save'></i>
                    Selesai</a>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- / Content -->