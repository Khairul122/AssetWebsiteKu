<?php
$username = $_SESSION['username'];
$query = mysqli_query($conn, "select * from jurnal_penyesuaian a join akun b on a.no_akun=b.no_akun");
if (empty($_GET['pesan'])) {
  $pesan = '';
} else {
  $pesan = $_GET['pesan'];
}
?>
<?php
if ($pesan == "Berhasil") {
  ?>
  <p class="alert alert-success">
    <?php echo $pesan ?>
  </p>
  <?php
} else if ($pesan == "Gagal") {
  ?>
    <p class="alert alert-danger">
    <?php echo $pesan ?>
    </p>
  <?php
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">
  <a href="index.php?link=tambah_jurnal_penyesuaian" class="btn btn-primary btn-xs"><i
      class="menu-icon tf-icons bx bx-plus"></i> Jurnal Penyesuaian</a>
  <!-- Basic Bootstrap Table -->

  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data Jurnal Penyesuaian</h6>
    </div>
    <div class="card-body">
      <h5 class="card-header"></h5>
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>No</th>
              <th>No Jurnal</th>
              <th>Tanggal</th>
              <th>No Akun</th>
              <th>Nama Akun</th>
              <th>Debit</th>
              <th>Kredit</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody class="table-border-bottom-0">
            <?php
            $no = 0;
            $debet = 0;
            $kredit = 0;
            while ($panggil = mysqli_fetch_array($query)) {
              # code...
              $no++;
              $aksi = "<a href='index.php?link=hapus_jurnal_penyesuaian&id_jurnal_penyesuaian=$panggil[id_jurnal_penyesuaian]' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a>";
              echo "
                        <tr>
                          <td>$no</td>
                          <td>$panggil[no_jurnal]</td>
                          <td>$panggil[tgl_jurnal]</td>
                          <td>$panggil[no_akun]</td>
                          <td>$panggil[nama_akun]</td>
                          <td>" . number_format($panggil['debet']) . "</td>
                          <td>" . number_format($panggil['kredit']) . "</td>
                          <td>$aksi</td>
                        </tr>";

              $debet = $debet + $panggil['debet'];
              $kredit = $kredit + $panggil['kredit'];
            }
            if ($debet == $kredit) {

              $ket = "Balance";
            } else {
              $ket = "Selisih " . ($debet - $kredit);
            }
            ?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="5" align="right">Total</td>
              <td>
                <?php echo number_format($debet) ?>
              </td>
              <td>
                <?php echo number_format($kredit) ?>
              </td>
              <td>
                <?php echo $ket ?>
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->