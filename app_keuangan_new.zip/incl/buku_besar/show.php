<?php
$username = $_SESSION['username'];
if(!empty($_POST['no_akun'])){
  $no_akun=$_POST['no_akun'];
}else{
  $no_akun="";
}
$query = mysqli_query($conn, "select * from jurnal_umum a join akun b on a.no_akun=b.no_akun where a.no_akun='$no_akun'");


$querysaldo_awal = mysqli_query($conn, "select sum(debet) as debet,sum(kredit) as kredit from saldo_awal where no_akun='$no_akun'");
$panggilsaldoawal=mysqli_fetch_array($querysaldo_awal);
if (empty($_GET['pesan'])) {
  $pesan = '';
} else {
  $pesan = $_GET['pesan'];
}
?>
<?php
if ($pesan == "Berhasil") {
  ?>
  <p class="alert alert-success">
    <?php echo $pesan ?>
  </p>
  <?php
} else if ($pesan == "Gagal") {
  ?>
    <p class="alert alert-danger">
    <?php echo $pesan ?>
    </p>
  <?php
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">
 
  <!-- Basic Bootstrap Table -->

  <div class="card shadow mb-4">
    <div class="card-header py-3">
        <form action="" method="post">
        <div class="row mb-3">
              <label class="col-sm-2 col-form-label" for="basic-default-company">No Akun</label>
              <div class="col-sm-8">
                <select name="no_akun" id="" class="form-control" id="basic-default-company" required>
                  <option value="">Pilih</option>
                  <?php
                  $queryakun = mysqli_query($conn, "select * from akun");
                  while ($data = mysqli_fetch_array($queryakun)) {
                    # code...
                    if ($no_akun == $data['no_akun']) {
                      $select = "selected";
                    } else {
                      $select = "";
                    }
                    ?>
                    <option value="<?php echo $data['no_akun'] ?>" <?php echo $select ?>>
                      <?php echo $data['nama_akun'] ?>
                    </option>
                    <?php
                  }
                  ?>
                </select>
              </div>
              <label class="col-sm-2" for="">
                <div class="col-sm-10">
                  <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Cari</button>
                </div>
              </label>
            </div>
        </form>
      <h6 class="m-0 font-weight-bold text-primary">Data Buku Besar</h6>
    </div>
    <div class="card-body">
      <h5 class="card-header"></h5>
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>No</th>
              <th>No Jurnal</th>
              <th>Tanggal</th>
              <th>No Akun</th>
              <th>Nama Akun</th>
              <th>Debit</th>
              <th>Kredit</th>
              <th>Saldo</th>
            </tr>
          </thead>
          <tbody class="table-border-bottom-0">
            <tr>
              <td colspan="5" align="center"><b>Saldo Awal</b></td>
              <td><?php echo number_format($panggilsaldoawal['debet']); ?></td>
              <td><?php echo number_format($panggilsaldoawal['kredit']); ?></td>
            </tr>
            <?php
            $no = 0;
            $saldo=$panggilsaldoawal['debet']-$panggilsaldoawal['kredit'];
            while ($panggil = mysqli_fetch_array($query)) {
              # code...
              $no++;
              $saldo=$saldo+$panggil['debet']-$panggil['kredit'];
              echo "
                        <tr>
                          <td>$no</td>
                          <td>$panggil[no_jurnal]</td>
                          <td>$panggil[tgl_jurnal]</td>
                          <td>$panggil[no_akun]</td>
                          <td>$panggil[nama_akun]</td>
                          <td>" . number_format($panggil['debet']) . "</td>
                          <td>" . number_format($panggil['kredit']) . "</td>
                          <td>" . number_format($saldo) . "</td>
                        </tr>";

            }
            ?>
          </tbody>
          
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->