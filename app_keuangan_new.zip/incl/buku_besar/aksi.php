<?php
if (empty($_GET['link'])) {
    $link = '';
} else {
    $link = $_GET['link'];
}
if (empty($_GET['aksi'])) {
    $aksi = '';
} else {
    $aksi = $_GET['aksi'];
}
switch ($link) {
    case 'tambah_jurnal_penyesuaian':
        # code...
        $username = $_SESSION['username'];
        $no_jurnal = $_POST['no_jurnal'];
        $no_akun = $_POST['no_akun'];
        $debet = $_POST['debet'];
        $kredit = $_POST['kredit'];
        $tgl_jurnal = $_POST['tgl_jurnal'];
        $tgl_insert = date('Y-m-d H:i:s');

            $query = mysqli_query($conn, "insert into jurnal_penyesuaian values (null, '$no_jurnal', '$tgl_jurnal','$no_akun','$debet','$kredit','$username','$tgl_insert','Proses')");
            if ($query > 0) {
                header("Location: index.php?link=tambah_jurnal_penyesuaian&pesan=Berhasil");
            } else {
                header("Location: index.php?link=tambah_jurnal_penyesuaian&pesan=Gagal");
            }
        
        // echo $nomor_antrian;
        break;
    case 'hapus_jurnal_penyesuaian':
        # code...
        $id_jurnal_penyesuaian = $_GET['id_jurnal_penyesuaian'];
        $query = mysqli_query($conn, "delete from jurnal_penyesuaian where id_jurnal_penyesuaian='$id_jurnal_penyesuaian'");
        if ($query > 0) {
            header("Location: index.php?link=jurnal_penyesuaian");
        } else {
            header("Location: index.php?link=jurnal_penyesuaian");
        }
        break;
    case 'hapus_jurnal_penyesuaian_':
        # code...
        $id_jurnal_penyesuaian = $_GET['id_jurnal_penyesuaian'];
        $query = mysqli_query($conn, "delete from jurnal_penyesuaian where id_jurnal_penyesuaian='$id_jurnal_penyesuaian'");
        if ($query > 0) {
            header("Location: index.php?link=tambah_jurnal_penyesuaian");
        } else {
            header("Location: index.php?link=tambah_jurnal_penyesuaian");
        }
        break;
    case 'selesai_jurnal_penyesuaian':
        # code...
        $no_jurnal = $_GET['no_jurnal'];
        $query = mysqli_query($conn, "update jurnal_penyesuaian set status='Selesai' where no_jurnal='$no_jurnal'");
        if ($query > 0) {
            header("Location: index.php?link=jurnal_penyesuaian");
        } else {
            header("Location: index.php?link=jurnal_penyesuaian");
        }
        break;

    default:
        # code...
        break;
}
?>