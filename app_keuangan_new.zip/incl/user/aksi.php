<?php
if (empty($_GET['link'])) {
    $link = '';
} else {
    $link = $_GET['link'];
}
if (empty($_GET['aksi'])) {
    $aksi = '';
} else {
    $aksi = $_GET['aksi'];
}
switch ($link) {
    case 'tambah_user':
        # code...
        $pass = md5($_POST['pass']);
        $nama = $_POST['nama'];
        $email = $_POST['email'];
        $querycek = mysqli_query($conn, "select * from admin where email='$email'");
        $cek = mysqli_num_rows($querycek);
        if ($cek < 1) {
            $query = mysqli_query($conn, "insert into admin values (null,'$nama','$email','$pass')");
        }

        if ($query > 0) {
            header("Location: index.php?link=user&pesan=Berhasil");
        } else {
            header("Location: index.php?link=user&pesan=Gagal");
        }
        break;
    case 'edit_user':
        # code...
        $email = $_POST['email'];
        $pass = md5($_POST['pass']);
        $nama = $_POST['nama'];
        if (empty($_POST['pass'])) {
            $query = mysqli_query($conn, "update admin set nama='$nama', email='$email' where email='$email'");

        } else {
            $query = mysqli_query($conn, "update admin set pass='$pass', nama='$nama' where email='$email'");

        }
        if ($query > 0) {
            header("Location: index.php?link=user&pesan=Berhasil");
        } else {
            header("Location: index.php?link=user&pesan=Gagal");
        }
        break;
    case 'hapus_user':
        # code...
        $email = $_GET['email'];
        $query = mysqli_query($conn, "delete from admin where email='$email'");
        if ($query > 0) {
            header("Location: index.php?link=user");
        } else {
            header("Location: index.php?link=user");
        }
        break;
   
    default:
        # code...
        break;
}
?>