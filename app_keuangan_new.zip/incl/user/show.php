<?php
$query=mysqli_query($conn,"select * from admin");
if (empty($_GET['pesan'])) {
  $pesan = '';
} else {
  $pesan = $_GET['pesan'];
}
?>

    <!-- Begin Page Content -->
    <div class="container-fluid">
            <!-- Content -->
            <div class="container-xxl flex-grow-1 container-p-y">
              <?php
                if($pesan=="Berhasil"){
                  ?>
                  <p class="alert alert-success"><?php echo $pesan ?></p>
                  <?php
                }else if($pesan=="Gagal"){
                  ?>
                  <p class="alert alert-danger"><?php echo $pesan ?></p>
                  <?php
                }
              ?>
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Menu /</span> user</h4>

              <!-- Basic Bootstrap Table -->
              <div class="card">
                <h5 class="card-header"><a href="index.php?link=tambah_user" class="btn btn-primary btn-xs"><i class="fas fa-plus"></i> user</a></h5>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Email</th>
                        <th>Nama Lengkap</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php
                      $no=0;
                      while ($panggil=mysqli_fetch_array($query)) {
                        # code...
                        $no++;
                        $aksi="<a href='index.php?link=edit_user&email=$panggil[email]' class='btn btn-primary btn-xs'><i class='fas fa-pen'></i></a><a href='index.php?link=hapus_user&email=$panggil[email]' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a>";
                        echo "
                        <tr>
                          <td>$no</td>
                          <td>$panggil[email]</td>
                          <td>$panggil[nama]</td>
                          <td>$aksi</td>
                        </tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <!--/ Basic Bootstrap Table -->

            

              <hr class="my-5" />

             
            </div>
            <!-- / Content -->