<?php
$email = $_GET['email'];
$query = mysqli_query($conn, "select * from admin where email='$email'");
$panggil = mysqli_fetch_array($query);
?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Menu /</span> Edit user</h4>

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col">
                <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">

                    </div>
                    <div class="card-body">
                        <form action="index.php?link=edit_user&aksi=simpan" method="POST">
                            <input type="hidden" name="email" class="form-control" id="basic-default-name"
                                placeholder="" value="<?php echo $panggil['email'] ?>" />
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">email</label>
                                <div class="col-sm-10">
                                    <input type="text" name="nama_user" class="form-control" id="basic-default-name"
                                        placeholder="Nama user" value="<?php echo $panggil['email'] ?>" readonly />
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-email">Password</label>
                                <div class="col-sm-10">
                                    <div class="input-group input-group-merge">
                                        <input type="text" id="basic-default-email" name="pass" class="form-control"
                                            placeholder="**" value="" aria-label="**"
                                            aria-describedby="basic-default-email2" />

                                    </div>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-phone">Nama Lengkap</label>
                                <div class="col-sm-10">
                                    <input type="text" name="nama" id="basic-default-phone"
                                        class="form-control phone-mask" value="<?php echo $panggil['nama'] ?>"
                                        placeholder="nama" aria-describedby="basic-default-phone" />
                                </div>
                            </div>

                            
                            <div class="row justify-content-end">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->