<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="container-xxl flex-grow-1 container-p-y">

    <!-- Basic Layout & Basic with Icons -->
    <div class="row">
      <!-- Basic Layout -->
      <div class="col">
        <div class="card mb-12">
          <div class="card-header d-flex align-items-center justify-content-between">

          </div>
          <div class="card-body">
            <form action="index.php?link=tambah_barang&aksi=simpan" method="POST">
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Merk Barang</label>
                <div class="col-sm-10">
                  <input type="text" name="merk_barang" class="form-control" id="basic-default-name"
                    placeholder="Merk Barang" />
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Nama Barang</label>
                <div class="col-sm-10">
                  <input type="text" name="nama_barang" class="form-control" id="basic-default-name"
                    placeholder="Nama Barang" />
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Stock Barang</label>
                <div class="col-sm-10">
                  <input type="number" name="stock_barang" class="form-control" id="basic-default-name"
                    placeholder="Stock Barang" />
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Stock Minimum</label>
                <div class="col-sm-10">
                  <input type="number" name="stock_minimum" class="form-control" id="basic-default-name"
                    placeholder="Stock Minimum" />
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Harga Beli</label>
                <div class="col-sm-10">
                  <input type="number" name="harga_beli" class="form-control" id="basic-default-name"
                    placeholder="Harga Beli" />
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Harga Jual</label>
                <div class="col-sm-10">
                  <input type="number" name="harga_jual" class="form-control" id="basic-default-name"
                    placeholder="Harga Jual" />
                </div>
              </div>

              <div class="row justify-content-end">
                <div class="col-sm-10">
                  <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- / Content -->