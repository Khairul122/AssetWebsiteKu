<?php
$kd_barang = $_GET['kd_barang'];
$query = mysqli_query($conn, "select * from tb_barang where kd_barang='$kd_barang'");
$panggil = mysqli_fetch_array($query);
?>
<!-- Begin Page Content -->
<div class="container-fluid">


    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col">
                <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">

                    </div>
                    <div class="card-body">
                        <form action="index.php?link=edit_barang&aksi=simpan" method="POST">
                            <input type="hidden" name="kd_barang" class="form-control" id="basic-default-name"
                                placeholder="" value="<?php echo $panggil['kd_barang'] ?>" />

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Merk Barang</label>
                                <div class="col-sm-10">
                                    <input type="text" name="merk_barang" class="form-control" id="basic-default-name"
                                        placeholder="Merk Barang" value="<?php echo $panggil['merk_barang'] ?>" />
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Nama Barang</label>
                                <div class="col-sm-10">
                                    <input type="text" name="nama_barang" class="form-control" id="basic-default-name"
                                        placeholder="Nama Barang" value="<?php echo $panggil['nama_barang'] ?>" />
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Stock Barang</label>
                                <div class="col-sm-10">
                                    <input type="number" name="stock_barang" class="form-control" id="basic-default-name"
                                        placeholder="Stock Barang" value="<?php echo $panggil['stock_barang'] ?>" />
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Stock Minimum</label>
                                <div class="col-sm-10">
                                    <input type="number" name="stock_minimum" class="form-control" id="basic-default-name"
                                        placeholder="Stock Minimum" value="<?php echo $panggil['stock_minimum'] ?>" />
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Harga Beli</label>
                                <div class="col-sm-10">
                                    <input type="number" name="harga_beli" class="form-control" id="basic-default-name"
                                        placeholder="Harga Beli" value="<?php echo $panggil['harga_beli'] ?>" />
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Harga Jual</label>
                                <div class="col-sm-10">
                                    <input type="number" name="harga_jual" class="form-control" id="basic-default-name"
                                        placeholder="Harga Jual" value="<?php echo $panggil['harga_jual'] ?>" />
                                </div>
                            </div>

                            <div class="row justify-content-end">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->