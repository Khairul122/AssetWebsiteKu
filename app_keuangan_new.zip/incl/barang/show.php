<?php
$query = mysqli_query($conn, "select * from tb_barang");
if (empty($_GET['pesan'])) {
  $pesan = '';
} else {
  $pesan = $_GET['pesan'];
}
?>
              <?php
              if ($pesan == "Berhasil") {
                ?>
                      <p class="alert alert-success"><?php echo $pesan ?></p>
                      <?php
              } else if ($pesan == "Gagal") {
                ?>
                          <p class="alert alert-danger"><?php echo $pesan ?></p>
                      <?php
              }
              ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <a href="index.php?link=tambah_barang" class="btn btn-primary btn-xs"><i class="fas fa-plus"></i></a>
        <!-- Page Heading -->
        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Data Barang</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Merk Barang</th>
                                <th>Nama Barang</th>
                                <th>Stok Barang</th>
                                <th>Stok Minimum</th>
                                <th>Harga Beli</th>
                                <th>Harga Jual</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                      $no=0;
                      while ($panggil=mysqli_fetch_array($query)) {
                        # code...
                        $no++;
                        echo "
                            <tr>
                                <td>$no</td>
                                <td>$panggil[merk_barang]</td>
                                <td>$panggil[nama_barang]</td>
                                <td>$panggil[stock_barang]</td>
                                <td>$panggil[stock_minimum]</td>
                                <td>$panggil[harga_beli]</td>
                                <td>$panggil[harga_jual]</td>
                                <td><a href='index.php?link=edit_barang&kd_barang=$panggil[kd_barang]' class='btn btn-primary btn-xs'><i class='fas fa-pen'></i></a><a href='index.php?link=hapus_barang&kd_barang=$panggil[kd_barang]' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a></td>
                            </tr>";
                      }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->