<?php
if (empty($_GET['link'])) {
    $link = '';
} else {
    $link = $_GET['link'];
}
if (empty($_GET['aksi'])) {
    $aksi = '';
} else {
    $aksi = $_GET['aksi'];
}
switch ($link) {
    case 'tambah_barang':
        # code...
        $merk_barang = $_POST['merk_barang'];
        $nama_barang = $_POST['nama_barang'];
        $stock_barang = $_POST['stock_barang'];
        $stock_minimum = $_POST['stock_minimum'];
        $harga_beli = $_POST['harga_beli'];
        $harga_jual = $_POST['harga_jual'];

        $query = mysqli_query($conn, "insert into tb_barang values (null,'$merk_barang','$nama_barang','$stock_barang','$stock_minimum','$harga_beli','$harga_jual')");
        if ($query > 0) {
            header("Location: index.php?link=barang&pesan=Berhasil");
        } else {
            header("Location: index.php?link=barang&pesan=Gagal");
        }


        // echo $nomor_antrian;
        break;
    case 'edit_barang':
        # code...
        $kd_barang = $_POST['kd_barang'];
        $merk_barang = $_POST['merk_barang'];
        $nama_barang = $_POST['nama_barang'];
        $stock_barang = $_POST['stock_barang'];
        $stock_minimum = $_POST['stock_minimum'];
        $harga_beli = $_POST['harga_beli'];
        $harga_jual = $_POST['harga_jual'];
        $query = mysqli_query($conn, "update tb_barang set merk_barang='$merk_barang',nama_barang='$nama_barang', stock_barang='$stock_barang', stock_minimum='$stock_minimum', harga_beli='$harga_beli',harga_jual='$harga_jual' where kd_barang='$kd_barang'");
        if ($query > 0) {
            header("Location: index.php?link=barang&pesan=Berhasil");
        } else {
            header("Location: index.php?link=barang&pesan=Gagal");
        }
        break;
    case 'hapus_barang':
        # code...
        $kd_barang = $_GET['kd_barang'];
        $query = mysqli_query($conn, "delete from tb_barang where kd_barang='$kd_barang'");
        if ($query > 0) {
            header("Location: index.php?link=barang");
        } else {
            header("Location: index.php?link=barang");
        }
        break;

    default:
        # code...
        break;
}
?>