<?php
if (empty($_GET['link'])) {
    $link = '';
} else {
    $link = $_GET['link'];
}
if (empty($_GET['aksi'])) {
    $aksi = '';
} else {
    $aksi = $_GET['aksi'];
}
switch ($link) {
    case 'tambah_akun':
        # code...
        
        $induk = $_POST['induk'];
        if(empty($induk)){
            $dinduk=0;
            $level=0;
        }else{

            $dinduk=$induk;
            $level=1;
        }
        $no_akun = $_POST['no_akun'];
        $nama_akun = $_POST['nama_akun'];
        $cek=mysqli_num_rows(mysqli_query($conn,"select * from akun where no_akun='$no_akun'"));
        if($cek>0){
            header("Location: index.php?link=akun&pesan=Gagal");
            
        }else{
            $query = mysqli_query($conn, "insert into akun values ('$no_akun','$dinduk','$level','$nama_akun')");
            if ($query > 0) {
    
                header("Location: index.php?link=akun&pesan=Berhasil");
            } else {
                header("Location: index.php?link=akun&pesan=Gagal");
            }
        }



        // echo $nomor_antrian;
        break;
    case 'edit_akun':
        # code...
        $induk = $_POST['induk'];
        $no_akun = $_POST['no_akun'];
        $nama_akun = $_POST['nama_akun'];
        $query = mysqli_query($conn, "update akun set induk='$induk',nama_akun='$nama_akun' where no_akun='$no_akun'");
        if ($query > 0) {
            header("Location: index.php?link=akun&pesan=Berhasil");
        } else {
            header("Location: index.php?link=akun&pesan=Gagal");
        }
        break;
    case 'hapus_akun':
        # code...
        $no_akun = $_GET['no_akun'];
        $query = mysqli_query($conn, "delete from akun where no_akun='$no_akun'");
        if ($query > 0) {
            header("Location: index.php?link=akun");
        } else {
            header("Location: index.php?link=akun");
        }
        break;

    default:
        # code...
        break;
}
?>