<?php
$no_akun = $_GET['no_akun'];
$query = mysqli_query($conn, "select * from akun where no_akun='$no_akun'");
$panggil = mysqli_fetch_array($query);
?>
<!-- Begin Page Content -->
<div class="container-fluid">


    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col">
                <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">

                    </div>
                    <div class="card-body">
                        <form action="index.php?link=edit_akun&aksi=simpan" method="POST">
                            <input type="hidden" name="no_akun" class="form-control" id="basic-default-name"
                                placeholder="" value="<?php echo $panggil['no_akun'] ?>" />

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Induk</label>
                                <div class="col-sm-6">
                                    <select name="induk" id="" class="form-control" id="basic-default-company" required>
                                        <option value="">Pilih</option>
                                        <?php
                                        $query = mysqli_query($conn, "select * from akun where level=0");
                                        while ($data = mysqli_fetch_array($query)) {
                                            # code...
                                            if($data['no_akun']==$panggil['induk']){
                                                $select="selected";
                                            }else{
                                                
                                                $select="";
                                            }
                                        
                                            ?>
                                            <option value="<?php echo $data['no_akun'] ?>" <?php echo $select ?>>
                                                <?php echo $data['nama_akun'] ?>
                                            </option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Nama Akun</label>
                                <div class="col-sm-10">
                                    <input type="text" name="nama_akun" class="form-control" id="basic-default-name"
                                        placeholder="Nama Akun" value="<?php echo $panggil['nama_akun'] ?>" />
                                </div>
                            </div>

                            <div class="row justify-content-end">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->