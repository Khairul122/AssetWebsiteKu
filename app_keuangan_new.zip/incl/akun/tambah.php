<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="container-xxl flex-grow-1 container-p-y">

    <!-- Basic Layout & Basic with Icons -->
    <div class="row">
      <!-- Basic Layout -->
      <div class="col">
        <div class="card mb-3">
          <div class="card-header d-flex align-items-center justify-content-between">

          </div>
          <div class="card-body">
            <form action="index.php?link=tambah_akun&aksi=simpan" method="POST">
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Akun Induk</label>
                <div class="col-sm-4">
                  <select name="induk" id="" class="form-control" id="basic-default-company" required>
                    <option value="">Pilih</option>
                    <?php
                    $query = mysqli_query($conn, "select * from akun where level=0");
                    while ($data = mysqli_fetch_array($query)) {
                      # code...
                      
                      ?>
                      <option value="<?php echo $data['no_akun'] ?>">
                        <?php echo $data['nama_akun'] ?>
                      </option>
                      <?php
                    }
                    ?>
                  </select>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">No Akun</label>
                <div class="col-sm-10">
                  <input type="text" name="no_akun" class="form-control" id="basic-default-name"
                    placeholder="No Akun" />
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Nama Akun</label>
                <div class="col-sm-10">
                  <input type="text" name="nama_akun" class="form-control" id="basic-default-name"
                    placeholder="Nama Akun" />
                </div>
              </div>
              <div class="row justify-content-end">
                <div class="col-sm-10">
                  <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- / Content -->