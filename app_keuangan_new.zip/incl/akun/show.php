<?php
$query = mysqli_query($conn, "select * from akun");
if (empty($_GET['pesan'])) {
    $pesan = '';
} else {
    $pesan = $_GET['pesan'];
}
?>
<?php
if ($pesan == "Berhasil") {
    ?>
    <p class="alert alert-success">
        <?php echo $pesan ?>
    </p>
    <?php
} else if ($pesan == "Gagal") {
    ?>
        <p class="alert alert-danger">
        <?php echo $pesan ?>
        </p>
    <?php
}
?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <a href="index.php?link=tambah_akun" class="btn btn-primary btn-xs"><i class="fas fa-plus"></i></a>
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Akun</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>No Akun</th>
                            <th>Nama Akun</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        while ($panggil = mysqli_fetch_array($query)) {
                            # code...
                            $no++;
                            echo "
                            <tr>
                                <td>$no</td>
                                <td>$panggil[no_akun]</td>
                                <td>$panggil[nama_akun]</td>
                                <td><a href='index.php?link=edit_akun&no_akun=$panggil[no_akun]' class='btn btn-primary btn-xs'><i class='fas fa-pen'></i></a><a href='index.php?link=hapus_akun&no_akun=$panggil[no_akun]' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a></td>
                            </tr>";

                            


                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->