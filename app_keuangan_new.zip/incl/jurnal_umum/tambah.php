<?php

$hari_in = hari_ini();
$tgl = date('Y-m-d');
$query = mysqli_query($conn, "SELECT max(no_jurnal) as kodeTerbesar FROM jurnal_umum where  status='Selesai'");
$data = mysqli_fetch_array($query);
$nomor_jurnal = (int) substr($data['kodeTerbesar'], 6, 5);
$nomor_jurnal++;
$char = date('ymd');
$newID = $char . sprintf("%05s", $nomor_jurnal);


$query_penjualan = mysqli_query($conn, "select * from jurnal_umum t1 join akun t2 on t1.no_akun=t2.no_akun where t1.no_jurnal='$newID'");
$query_penjualanlagi = mysqli_query($conn, "select * from jurnal_umum t1 join akun t2 on t1.no_akun=t2.no_akun where t1.no_jurnal='$newID'");
$ambil = mysqli_fetch_array($query_penjualanlagi);
?>
<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="container-xxl flex-grow-1 container-p-y">

    <!-- Basic Layout & Basic with Icons -->
    <div class="row">
      <!-- Basic Layout -->
      <div class="col">
        <div class="card mb-3">
          <div class="card-header d-flex align-items-center justify-content-between">

          </div>
          <div class="card-body">
          <form action="index.php?link=tambah_jurnal_umum&aksi=simpan" method="POST">
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label" for="basic-default-message">No jurnal</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" placeholder="No Jurnal" name="no_jurnal"
                  value="<?php echo $newID ?>" id="" readonly>
              </div>


              <label class="col-sm-2 col-form-label" for="basic-default-message">Tanggal</label>
              <div class="col-sm-4">
                <input type="date" class="form-control" placeholder="Tanggal" name="tgl_jurnal"
                  value="<?php echo date('Y-m-d') ?>" id="">
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label" for="basic-default-company">No Bukti</label>
              <div class="col-sm-4">

                <input type="text" name="no_bukti" value="<?php echo $ambil['no_bukti'] ?>" autocomplete="off"
                  class="form-control" id="">
              </div>

              <label class="col-sm-2 col-form-label" for="basic-default-company">Keterangan</label>
              <div class="col-sm-4">

                <input type="text" name="ket" value="<?php echo $ambil['ket'] ?>" autocomplete="off"
                  class="form-control" id="">
              </div>

            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label" for="basic-default-company">No Akun</label>
              <div class="col-sm-10">
                <select name="no_akun" id="" class="form-control" id="basic-default-company" required>
                  <option value="">Pilih</option>
                  <?php
                  $query = mysqli_query($conn, "select * from akun");
                  while ($data = mysqli_fetch_array($query)) {
                    # code...
                    if ($ambil['no_akun'] == $data['no_akun']) {
                      $select = "selected";
                    } else {
                      $select = "";
                    }
                    ?>
                    <option value="<?php echo $data['no_akun'] ?>" <?php echo $select ?>>
                      <?php echo $data['nama_akun'] ?>
                    </option>
                    <?php
                  }
                  ?>
                </select>
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label" for="basic-default-message">Debet</label>
              <div class="col-sm-2">
                <input type="number" class="form-control" placeholder="Debet" name="debet" id="" required>
              </div>
              <label class="col-sm-2 col-form-label" for="basic-default-message">Kredit</label>
              <div class="col-sm-2">
                <input type="number" class="form-control" placeholder="kredit" name="kredit" id="" required>
              </div>
              <label class="col-sm-2" for="">
                <div class="col-sm-10">
                  <button type="submit" class="btn btn-primary"> Add</button>
                </div>
              </label>
            </div>

            <div class="card">
              <div class="table-responsive text-nowrap">
                <table class="table">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>No AKun</th>
                      <th>Nama Akun</th>
                      <th>Debet</th>
                      <th>Kredit</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tbody class="table-border-bottom-0">
                    <?php
                    $no = 0;
                    $tot = 0;
                    $debet = 0;
                    $kredit = 0;
                    while ($panggil = mysqli_fetch_array($query_penjualan)) {
                      # code...
                      $no++;
                      $aksi = "<a href='index.php?link=hapus_jurnal_umum_&id_jurnal_umum=$panggil[id_jurnal_umum]' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a>";
                      echo "
                        <tr>
                          <td>$no</td>
                          <td>$panggil[no_akun]</td>
                          <td>$panggil[nama_akun]</td>
                          <td>" . number_format($panggil['debet']) . "</td>
                          <td>" . number_format($panggil['kredit']) . "</td>
                          <td>$aksi</td>
                        </tr>";


                      $debet = $debet + $panggil['debet'];
                      $kredit = $kredit + $panggil['kredit'];
                    }
                    if ($debet == $kredit) {

                      $ket = "Balance";
                    } else {
                      $ket = "Selisih " . ($debet - $kredit);
                    }
                    ?>
                  </tbody>

                  <tfoot>
                    <tr>
                      <td colspan="3" align="right">Total</td>
                      <td>
                        <?php echo number_format($debet) ?>
                      </td>
                      <td>
                        <?php echo number_format($kredit) ?>
                      </td>
                      <td>
                        <?php echo $ket ?>
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>




        </div>

        <div class="row justify-content-end">
          <div class="col-sm-10">
            <a href="index.php?link=selesai_jurnal&no_jurnal=<?php echo $newID ?>" class="btn btn-primary btn-xs"><i
                class='fas fa-save'></i>
              Selesai</a>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
<!-- / Content -->