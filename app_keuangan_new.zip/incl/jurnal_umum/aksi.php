<?php
if (empty($_GET['link'])) {
    $link = '';
} else {
    $link = $_GET['link'];
}
if (empty($_GET['aksi'])) {
    $aksi = '';
} else {
    $aksi = $_GET['aksi'];
}
switch ($link) {
    case 'tambah_jurnal_umum':
        # code...
        $username = $_SESSION['username'];
        $no_jurnal = $_POST['no_jurnal'];
        $ket = $_POST['ket'];
        $no_bukti = $_POST['no_bukti'];
        $no_akun = $_POST['no_akun'];
        $debet = $_POST['debet'];
        $kredit = $_POST['kredit'];
        $tgl_jurnal = $_POST['tgl_jurnal'];
        $tgl_insert = date('Y-m-d H:i:s');

            $query = mysqli_query($conn, "insert into jurnal_umum values (null, '$no_jurnal', '$tgl_jurnal','$ket','$no_bukti','$no_akun','$debet','$kredit','$username','$tgl_insert','Proses')");
            if ($query > 0) {
                header("Location: index.php?link=tambah_jurnal_umum&pesan=Berhasil");
            } else {
                header("Location: index.php?link=tambah_jurnal_umum&pesan=Gagal");
            }
        
        // echo $nomor_antrian;
        break;
    case 'hapus_jurnal_umum':
        # code...
        $id_jurnal_umum = $_GET['id_jurnal_umum'];
        $query = mysqli_query($conn, "delete from jurnal_umum where id_jurnal_umum='$id_jurnal_umum'");
        if ($query > 0) {
            header("Location: index.php?link=jurnal_umum");
        } else {
            header("Location: index.php?link=jurnal_umum");
        }
        break;
    case 'hapus_jurnal_umum_':
        # code...
        $id_jurnal_umum = $_GET['id_jurnal_umum'];
        $query = mysqli_query($conn, "delete from jurnal_umum where id_jurnal_umum='$id_jurnal_umum'");
        if ($query > 0) {
            header("Location: index.php?link=tambah_jurnal_umum");
        } else {
            header("Location: index.php?link=tambah_jurnal_umum");
        }
        break;
    case 'selesai_jurnal':
        # code...
        $no_jurnal = $_GET['no_jurnal'];
        $query = mysqli_query($conn, "update jurnal_umum set status='Selesai' where no_jurnal='$no_jurnal'");
        if ($query > 0) {
            header("Location: index.php?link=jurnal_umum");
        } else {
            header("Location: index.php?link=jurnal_umum");
        }
        break;

    default:
        # code...
        break;
}
?>