<!-- Nav Item - Dashboard -->
<li class="nav-item active">
    <a class="nav-link" href="index.php?link=beranda">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span></a>
</li>
<!-- Nav Item - Charts -->
<li class="nav-item">
    <a class="nav-link" href="index.php?link=barang">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Data Barang</span></a>
</li>

<!-- Nav Item - Charts -->
<li class="nav-item">
    <a class="nav-link" href="index.php?link=pembelian">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Pembelian</span></a>
</li>

<!-- Nav Item - Charts -->
<li class="nav-item">
    <a class="nav-link" href="index.php?link=penjualan">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Penjualan</span></a>
</li>

<!-- Nav Item - Utilities Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true"
        aria-controls="collapseUtilities">
        <i class="fas fa-fw fa-wrench"></i>
        <span>Pengaturan Keuangan</span>
    </a>
    <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="index.php?link=akun">Akun/COA</a>
            <a class="collapse-item" href="index.php?link=saldo_awal">Saldo Awal</a>
        </div>
    </div>
</li>


<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Transaksi
</div>
<!-- Nav Item - Utilities Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTransaksi" aria-expanded="true"
        aria-controls="collapseTransaksi">
        <i class="fas fa-fw fa-wrench"></i>
        <span>Transaksi Keuangan</span>
    </a>
    <div id="collapseTransaksi" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="index.php?link=jurnal_umum">Jurnal Umum</a>
            <a class="collapse-item" href="index.php?link=buku_besar">Buku Besar</a>
            <a class="collapse-item" href="index.php?link=jurnal_penyesuaian">Jurnal Penyesuaian</a>
        </div>
    </div>
</li>


<!-- Divider -->
<hr class="sidebar-divider">

<!-- Nav Item - Charts -->
<li class="nav-item">
    <a class="nav-link" href="index.php?link=laporan">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Laporan</span></a>
</li>


<!-- Nav Item - Charts -->
<li class="nav-item">
    <a class="nav-link" href="index.php?link=user">
        <i class="fas fa-fw fa-users"></i>
        <span>Manajemen User</span></a>
</li>