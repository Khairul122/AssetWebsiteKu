<?php
$id_saldo_awal = $_GET['id_saldo_awal'];
$query = mysqli_query($conn, "select * from saldo_awal where id_saldo_awal='$id_saldo_awal'");
$panggil = mysqli_fetch_array($query);
?>
<!-- Begin Page Content -->
<div class="container-fluid">


    <div class="container-xxl flex-grow-1 container-p-y">
        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
            <!-- Basic Layout -->
            <div class="col">
                <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">

                    </div>
                    <div class="card-body">
                        <form action="index.php?link=edit_saldo_awal&aksi=simpan" method="POST">
                            <input type="hidden" name="id_saldo_awal" class="form-control" id="basic-default-name"
                                placeholder="" value="<?php echo $panggil['id_saldo_awal'] ?>" />
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Periode</label>
                                <div class="col-sm-4">
                                    <select name="periode" id="" class="form-control" id="basic-default-company"
                                        required>
                                        <option value="">Pilih</option>
                                        <?php
                                        $tahun = date('Y') + 1;
                                        for ($i = 2023; $i <= $tahun; $i++) {
                                            # code...
                                            if ($panggil['periode'] == $i) {
                                                $select = "selected";
                                            } else {

                                                $select = "";
                                            }
                                            ?>
                                            <option value="<?php echo $i ?>" <?php echo $select ?>>
                                                <?php echo $i ?>
                                            </option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">No Akun</label>
                                <div class="col-sm-6">
                                    <select name="no_akun" id="" class="form-control" id="basic-default-company"
                                        required>
                                        <option value="">Pilih</option>
                                        <?php
                                        $query = mysqli_query($conn, "select * from akun");
                                        while ($data = mysqli_fetch_array($query)) {
                                            # code...
                                            if ($data['no_akun'] == $panggil['no_akun']) {
                                                $select = "selected";
                                            } else {

                                                $select = "";
                                            }

                                            ?>
                                            <option value="<?php echo $data['no_akun'] ?>" <?php echo $select ?>>
                                                <?php echo $data['nama_akun'] ?>
                                            </option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Debet</label>
                                <div class="col-sm-10">
                                    <input type="text" name="debet" class="form-control" id="basic-default-name"
                                        placeholder="Debet" value="<?php echo $panggil['debet'] ?>" />
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="basic-default-name">Kredit</label>
                                <div class="col-sm-10">
                                    <input type="text" name="kredit" class="form-control" id="basic-default-name"
                                        placeholder="Kredit" value="<?php echo $panggil['kredit'] ?>" />
                                </div>
                            </div>

                            <div class="row justify-content-end">
                                <div class="col-sm-10">
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->