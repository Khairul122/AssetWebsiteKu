<?php
$query = mysqli_query($conn, "select * from saldo_awal a join akun b on a.no_akun=b.no_akun");
if (empty($_GET['pesan'])) {
    $pesan = '';
} else {
    $pesan = $_GET['pesan'];
}
?>
<?php
if ($pesan == "Berhasil") {
    ?>
    <p class="alert alert-success">
        <?php echo $pesan ?>
    </p>
    <?php
} else if ($pesan == "Gagal") {
    ?>
        <p class="alert alert-danger">
        <?php echo $pesan ?>
        </p>
    <?php
}
?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <a href="index.php?link=tambah_saldo_awal" class="btn btn-primary btn-xs"><i class="fas fa-plus"></i></a>
    <!-- Page Heading -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Saldo Awal</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Periode</th>
                            <th>No Akun</th>
                            <th>Nama Akun</th>
                            <th>Debet</th>
                            <th>Kredit</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        $debet=0;
                        $kredit=0;
                        while ($panggil = mysqli_fetch_array($query)) {
                            # code...
                            $no++;
                            echo "
                            <tr>
                                <td>$no</td>
                                <td>$panggil[periode]</td>
                                <td>$panggil[no_akun]</td>
                                <td>$panggil[nama_akun]</td>
                                <td>$panggil[debet]</td>
                                <td>$panggil[kredit]</td>
                                <td><a href='index.php?link=edit_saldo_awal&id_saldo_awal=$panggil[id_saldo_awal]' class='btn btn-primary btn-xs'><i class='fas fa-pen'></i></a><a href='index.php?link=hapus_saldo_awal&id_saldo_awal=$panggil[id_saldo_awal]' class='btn btn-danger btn-xs'><i class='fas fa-trash'></i></a></td>
                            </tr>";

                            

                            $debet=$debet+$panggil['debet'];
                            $kredit=$kredit+$panggil['kredit'];
                            
                        }
                        if($debet==$kredit){
                                
                            $ket="Balance";
                        }else{
                            $ket="Selisih ".($debet-$kredit);
                        }
                        ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" align="right">Total</td>
                            <td><?php echo number_format($debet) ?></td>
                            <td><?php echo number_format($kredit) ?></td>
                            <td><?php echo $ket ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->