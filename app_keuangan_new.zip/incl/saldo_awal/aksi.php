<?php
if (empty($_GET['link'])) {
    $link = '';
} else {
    $link = $_GET['link'];
}
if (empty($_GET['aksi'])) {
    $aksi = '';
} else {
    $aksi = $_GET['aksi'];
}
switch ($link) {
    case 'tambah_saldo_awal':
        # code...
        $periode=$_POST['periode'];
        $date=date('Y-m-d');
        $username=$_SESSION['username'];
        $no_akun = $_POST['no_akun'];
        $debet = $_POST['debet'];
        $kredit = $_POST['kredit'];
            $query = mysqli_query($conn, "insert into saldo_awal values (null,'$periode','$no_akun','$debet','$kredit','$date','$username')");
            if ($query > 0) {
    
                header("Location: index.php?link=saldo_awal&pesan=Berhasil");
            } else {
                header("Location: index.php?link=saldo_awal&pesan=Gagal");
            }
        



        // echo $nomor_antrian;
        break;
    case 'edit_saldo_awal':
        # code...
        $id_saldo_awal = $_POST['id_saldo_awal'];
        $periode=$_POST['periode'];
        $date=date('Y-m-d');
        $username=$_SESSION['username'];
        $no_akun = $_POST['no_akun'];
        $debet = $_POST['debet'];
        $kredit = $_POST['kredit'];
        $query = mysqli_query($conn, "update saldo_awal set periode='$periode',no_akun='$no_akun',debet='$debet',kredit='$kredit' where id_saldo_awal='$id_saldo_awal'");
        if ($query > 0) {
            header("Location: index.php?link=saldo_awal&pesan=Berhasil");
        } else {
            header("Location: index.php?link=saldo_awal&pesan=Gagal");
        }
        break;
    case 'hapus_saldo_awal':
        # code...
        $id_saldo_awal = $_GET['id_saldo_awal'];
        $query = mysqli_query($conn, "delete from saldo_awal where id_saldo_awal='$id_saldo_awal'");
        if ($query > 0) {
            header("Location: index.php?link=saldo_awal");
        } else {
            header("Location: index.php?link=saldo_awal");
        }
        break;

    default:
        # code...
        break;
}
?>