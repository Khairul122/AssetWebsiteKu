<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="container-xxl flex-grow-1 container-p-y">

    <!-- Basic Layout & Basic with Icons -->
    <div class="row">
      <!-- Basic Layout -->
      <div class="col">
        <div class="card mb-3">
          <div class="card-header d-flex align-items-center justify-content-between">

          </div>
          <div class="card-body">
            <form action="index.php?link=tambah_saldo_awal&aksi=simpan" method="POST">
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Periode</label>
                <div class="col-sm-4">
                  <select name="periode" id="" class="form-control" id="basic-default-company" required>
                    <option value="">Pilih</option>
                    <?php
                    $tahun=date('Y')+1;
                    for ($i=2023; $i <= $tahun; $i++){
                      # code...
                    
                      ?>
                      <option value="<?php echo $i ?>">
                        <?php echo $i ?>
                      </option>
                      <?php
                    }
                    ?>
                  </select>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">No Akun</label>
                <div class="col-sm-4">
                  <select name="no_akun" id="" class="form-control" id="basic-default-company" required>
                    <option value="">Pilih</option>
                    <?php
                    $query = mysqli_query($conn, "select * from akun");
                    while ($data = mysqli_fetch_array($query)) {
                      # code...
                    
                      ?>
                      <option value="<?php echo $data['no_akun'] ?>">
                        <?php echo $data['nama_akun'] ?>
                      </option>
                      <?php
                    }
                    ?>
                  </select>
                </div>
              </div>
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Debet</label>
                <div class="col-sm-10">
                  <input type="number" name="debet" class="form-control" id="basic-default-name" placeholder="debet" />
                </div>
              </div>

              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Kredit</label>
                <div class="col-sm-10">
                  <input type="number" name="kredit" class="form-control" id="basic-default-name"
                    placeholder="Kredit" />
                </div>
              </div>
              <div class="row justify-content-end">
                <div class="col-sm-10">
                  <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- / Content -->