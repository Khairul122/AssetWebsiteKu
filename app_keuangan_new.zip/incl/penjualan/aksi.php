<?php
if (empty($_GET['link'])) {
    $link = '';
} else {
    $link = $_GET['link'];
}
if (empty($_GET['aksi'])) {
    $aksi = '';
} else {
    $aksi = $_GET['aksi'];
}
switch ($link) {
    case 'tambah_penjualan':
        # code...
        $username = $_SESSION['username'];
        $no_faktur = $_POST['no_faktur'];
        $kd_barang = $_POST['kd_barang'];
        $jumlah_jual = $_POST['jumlah_jual'];
        $tgl_penjualan = date('Y-m-d');

        $queryambil = mysqli_query($conn, "select * from tb_barang where kd_barang='$kd_barang'");
        $ambil = mysqli_fetch_array($queryambil);
        $nm_barang = $ambil['nama_barang'];
        $harga = $ambil['harga_jual'];

        $cekquery = mysqli_query($conn, "select * from tb_penjualan where kd_barang='$kd_barang' and no_faktur='$no_faktur'");
        $ambilcek = mysqli_num_rows($cekquery);
        if ($ambilcek < 1) {
            $query = mysqli_query($conn, "insert into tb_penjualan values (null, '$no_faktur', '$tgl_penjualan','$kd_barang','$nm_barang','$harga','$jumlah_jual','Proses')");
            if ($query > 0) {
                header("Location: index.php?link=tambah_penjualan&pesan=Berhasil");
            } else {
                header("Location: index.php?link=tambah_penjualan&pesan=Gagal");
            }
        } else {
            $query = mysqli_query($conn, "update tb_penjualan set jumlah_jual=jumlah_jual+'$jumlah_jual' where kd_barang='$kd_barang' and no_faktur='$no_faktur'");
            if ($query > 0) {
                header("Location: index.php?link=tambah_penjualan&pesan=Berhasil");
            } else {
                header("Location: index.php?link=tambah_penjualan&pesan=Gagal");
            }
        }
        // echo $nomor_antrian;
        break;
    case 'hapus_penjualan':
        # code...
        $id_penjualan = $_GET['id_penjualan'];
        $query = mysqli_query($conn, "delete from tb_penjualan where id_penjualan='$id_penjualan'");
        if ($query > 0) {
            header("Location: index.php?link=penjualan");
        } else {
            header("Location: index.php?link=penjualan");
        }
        break;
    case 'hapus_penjualan_':
        # code...
        $id_penjualan = $_GET['id_penjualan'];
        $query = mysqli_query($conn, "delete from tb_penjualan where id_penjualan='$id_penjualan'");
        if ($query > 0) {
            header("Location: index.php?link=tambah_penjualan");
        } else {
            header("Location: index.php?link=tambah_penjualan");
        }
        break;
    case 'selesai_penjualan':
        # code...
        $no_faktur = $_GET['no_faktur'];
        $query = mysqli_query($conn, "update tb_penjualan set status='Selesai' where no_faktur='$no_faktur'");
        if ($query > 0) {
            header("Location: index.php?link=tambah_penjualan");
        } else {
            header("Location: index.php?link=tambah_penjualan");
        }
        break;

    default:
        # code...
        break;
}
?>