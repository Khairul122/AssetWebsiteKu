<?php

$tgl = date('Y-m-d');
$query = mysqli_query($conn, "SELECT max(no_jurnal) as kodeTerbesar FROM jurnal_umum where  status='Selesai'");
$data = mysqli_fetch_array($query);
$nomor_jurnal = (int) substr($data['kodeTerbesar'], 6, 5);
$nomor_jurnal++;
$char = date('ymd');
$newID = $char . sprintf("%05s", $nomor_jurnal);


$query_penjualan = mysqli_query($conn, "select * from jurnal_umum t1 join akun t2 on t1.no_akun=t2.no_akun where t1.no_jurnal='$newID'");
$query_penjualanlagi = mysqli_query($conn, "select * from jurnal_umum t1 join akun t2 on t1.no_akun=t2.no_akun where t1.no_jurnal='$newID'");
$ambil = mysqli_fetch_array($query_penjualanlagi);




       $querypanggil=mysqli_query($conn,"select sum(harga*jumlah_jual) as total from tb_penjualan where status='Selesai' group by no_faktur");
       while($panggil=mysqli_fetch_array($querypanggil)){
        
        $total=$panggil['total'];
        $username = $_SESSION['username'];
        $no_jurnal = $newID;
        $ket = 'Ket';
        $no_bukti = '1';
        $no_akun = '4001';
        $debet = $total;
        $kredit = 0;
        $tgl_jurnal = date('Y-m-d');
        $tgl_insert = date('Y-m-d H:i:s');
        
            
            $query = mysqli_query($conn, "insert into jurnal_umum values (null, '$no_jurnal', '$tgl_jurnal','$ket','$no_bukti','$no_akun','$debet','$kredit','$username','$tgl_insert','Selesai')");

            
        $no_akun1 = '9001';
        $debet1 = 0;
        $kredit1 = $total;
            
            $querylagi = mysqli_query($conn, "insert into jurnal_umum values (null, '$no_jurnal', '$tgl_jurnal','$ket','$no_bukti','$no_akun1','$debet1','$kredit1','$username','$tgl_insert','Selesai')");
       }
        
       header("Location: index.php?link=jurnal_umum&pesan=BERHASIL");
        

?>