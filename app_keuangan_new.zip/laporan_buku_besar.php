<?php
include "incl/koneksi.php";

$periode=$_POST['periode'];
$no_akun=$_POST['no_akun'];
$query = mysqli_query($conn, "select * from jurnal_umum a join akun b on a.no_akun=b.no_akun where year(tgl_jurnal)='$periode'");
$querysaldoawal = mysqli_query($conn, "select sum(debet) as debet,sum(kredit) as kredit from saldo_awal where periode='$periode' and no_akun='$no_akun'");
$ambilsaldoawal=mysqli_fetch_array($querysaldoawal);
$saldoawal=$ambilsaldoawal['debet']-$ambilsaldoawal['kredit'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LAPORAN Buku Besar</title>
    <style>
        table {
            /* border:1px solid; */
            border-collapse: collapse;
            width: 100%;
        }

        td {
            border: 1px solid;
            padding: 8px 20px;
        }
    </style>
</head>

<!-- <body onload="javascript:window.print()"> -->
    <h1 align="center">ALFARA MOTOR</h1>
    <h3 align="center">LAPORAN JURNAL</h3> <h3 align="center"><?php echo "Dari Periode ".$periode." No Akun ".$no_akun ?></h3>
   
    <hr>
    <table class="table">
        <thead>
            <tr>
                <td>No</td>
                <td>No Jurnal</td>
                <td>Tanggal</td>
                <td>No Bukti</td>
                <td>Keterangan</td>
                <td>No Akun</td>
                <td>Nama Akun</td>
                <td>Debit</td>
                <td>Kredit</td>
                <td>Saldo</td>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            <tr>
                <td colspan="7" align="right">Saldo Awal</td>
                <td><?php echo number_format($ambilsaldoawal['debet']) ?></td>
                <td><?php echo number_format($ambilsaldoawal['kredit']) ?></td>
                <td><?php echo number_format($saldoawal) ?></td>
            </tr>
            <?php
            $no = 0;
            while ($panggil = mysqli_fetch_array($query)) {
                # code...
                $no++;
                $saldoawal=$saldoawal+($panggil['debet']-$panggil['kredit']);
                echo "
                        <tr>
                          <td>$no</td>
                          <td>$panggil[no_jurnal]</td>
                          <td>$panggil[tgl_jurnal]</td>
                          <td>$panggil[no_bukti]</td>
                          <td>$panggil[ket]</td>
                          <td>$panggil[no_akun]</td>
                          <td>$panggil[nama_akun]</td>
                          <td>".number_format($panggil['debet'])."</td>
                          <td>".number_format($panggil['kredit'])."</td>
                          <td>".number_format(abs($saldoawal))."</td>
                        </tr>";
            }
            ?>
        </tbody>
        <tr>
            <th colspan="8"></th>
            <th colspan="8"><br>Padang,
                <?php echo tgl_indo(date('Y-m-d')) ?><br><br><br><br><br><?php echo $_POST['penandatangan'] ?>
            </th>
        </tr>
    </table>
</body>

</html>