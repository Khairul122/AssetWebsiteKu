<?php
include "incl/koneksi.php";

$periode = $_POST['periode'];
$queryakun = mysqli_query($conn, "SELECT * FROM akun WHERE level=0 ORDER BY no_akun");
$itungrows = mysqli_num_rows($queryakun);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LAPORAN Buku Besar</title>
    <style>
        table {
            /* border:1px solid; */
            border-collapse: collapse;
            width: 100%;
        }

        td {
            border: 1px solid;
            padding: 8px 20px;
        }
    </style>
</head>

<!-- <body onload="javascript:window.print()"> -->
<h1 align="center">ALFARA MOTOR</h1>
<h3 align="center">LAPORAN NERACA SALDO</h3>
<h3 align="center">
    <?php echo "Dari Periode " . $periode ?>
</h3>

<hr>
<table id="table" width="100%">
<tr>
	<th rowspan="2">No</th>
    <th rowspan="2">No Rek</th>
    <th rowspan="2">Nama Rek</th>
    <th colspan="2">Neraca Saldo</th>
</tr>
<tr>
    <th>Debet</th>
    <th>Kredit</th>
</tr>    
<?php
	if($itungrows>0){
		$t_dr=0;
		$t_kr=0;
		$no =1;
		while ($db = mysqli_fetch_array($queryakun)) {
            $periode = $_POST['periode'];

			$no_akun = $db['no_akun'];
			$query = mysqli_query($conn, "select * from jurnal_umum a join akun b on a.no_akun=b.no_akun where year(tgl_jurnal)='$periode' and a.no_akun='$no_akun'");
			$panggil = mysqli_fetch_array($query);

			$querysaldoawal = mysqli_query($conn, "select sum(debet) as debet,sum(kredit) as kredit from saldo_awal where periode='$periode' and no_akun='$no_akun'");
			$ambilsaldoawal = mysqli_fetch_array($querysaldoawal);
			$saldoawal = $ambilsaldoawal['debet'] - $ambilsaldoawal['kredit'];
			$no++;
			$saldoawal = $saldoawal + ($panggil['debet'] - $panggil['kredit']);
			if ($saldoawal > 0) {
				$dr_ju = $saldoawal;
				$kr_ju = 0;
			} else {
				$dr_ju = 0;
				$kr_ju = abs($saldoawal);
			}
		?>    
    	<tr>
			<td align="center" width="20"><?php echo $no; ?></td>
            <td align="center" width="80" ><?php echo $db['no_akun']; ?></td>
            <td ><?php echo $db['nama_akun']; ?></td>
            <td align="right" width="80"><?php echo number_format($dr_ju); ?></td>
            <td align="right" width="80"><?php echo number_format($kr_ju); ?></td>
    </tr>
    <?php
		$t_dr = $t_dr+$dr_ju;
		$t_kr = $t_kr+$kr_ju;
		$no++;
		}
	}else{
		$t_dr=0;
		$t_kr=0;
	?>
    	<tr>
        	<td colspan="9" align="center" >Tidak Ada Data</td>
        </tr>
    <?php	
	}
?>
<tr>
	<td colspan="3" align="center">Saldo</td>
    <td align="right"><?php echo number_format($t_dr);?></td>
    <td align="right"><?php echo number_format($t_kr);?></td>
</tr>
<tr>
            <th colspan="3"></th>
            <th colspan="3"><br>Padang,
                <?php echo tgl_indo(date('Y-m-d')) ?><br><br><br><br><br><?php echo $_POST['penandatangan'] ?>
            </th>
        </tr>
</table>
</body>

</html>