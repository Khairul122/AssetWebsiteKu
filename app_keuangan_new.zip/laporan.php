<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Basic Layout & Basic with Icons -->
  <div class="row">
    <!-- Basic Layout -->
    <div class="col">
      <div class="card mb-4">
        <div class="card-header d-flex align-items-center justify-content-between">

        </div>
        <div class="card-body">
          <form action="cetak.php" method="POST" target="_blank">
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label" for="basic-default-name">Periode</label>
              <div class="col-sm-10">

                <select name="periode" id="" class="form-control" id="basic-default-company" required>
                  <option value="">Pilih</option>
                  <?php
                  $tahun = date('Y');
                  for ($i = 2023; $i <= $tahun; $i++) {
                    # code...
                  
                    ?>
                    <option value="<?php echo $i ?>">
                      <?php echo $i ?>
                    </option>
                    <?php
                  }
                  ?>
                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label class="col-sm-2 col-form-label" for="basic-default-company">Jenis</label>
              <div class="col-sm-8">
                <select name="jenis" id="" class="form-control" id="basic-default-company" required>
                  <option value="">Pilih</option>
                  <option value="1">Buku Besar</option>
                  <option value="2">Neraca Saldo</option>
                  <option value="3">Neraca Lajur</option>
                  <option value="4">Laba Rugi</option>
                  <option value="5">Neraca</option>

                </select>
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label" for="basic-default-name">No Akun (Pilih Jika Jenis Laporan Buku
                Besar)</label>
              <div class="col-sm-10">

                <select name="no_akun" id="" class="form-control" id="basic-default-company">
                  <option value="">Pilih</option>
                  <?php
                  $query = mysqli_query($conn, "select * from akun");
                  while ($data = mysqli_fetch_array($query)) {
                    # code...
                  
                    ?>
                    <option value="<?php echo $data['no_akun'] ?>">
                      <?php echo $data['nama_akun'] ?>
                    </option>
                    <?php
                  }
                  ?>
                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label class="col-sm-2 col-form-label" for="basic-default-name">Penandatangan</label>
              <div class="col-sm-10">

                <input type="text" class="form-control" name="penandatangan" id="">
              </div>
            </div>

            <div class="row justify-content-end">
              <div class="col-sm-10">
                <button type="submit" class="btn btn-primary"><i class="fa fa-print"></i> Cetak</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- / Content -->