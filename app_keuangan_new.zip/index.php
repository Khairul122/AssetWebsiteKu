<?php
session_start();

if(empty($_SESSION['username'])){

    header("location: login.php");
}else{
        include "incl/header.php";
        include "link.php";
        include "incl/footer.php";        
    
}
?>