<?php
session_start();
include "incl/koneksi.php";

# code...
// menangkap data yang dikirim dari form
$email = mysqli_real_escape_string($conn, $_POST['email']);
$pass = mysqli_real_escape_string($conn, md5($_POST['pass']));
$querycek = mysqli_query($conn, "select * from admin where email='$email' and pass='$pass'");
$data = mysqli_fetch_array($querycek);
$cek = mysqli_num_rows($querycek);
if ($cek > 0) {
    $_SESSION['username'] = $email;
    $_SESSION['nama_lengkap'] = $data['nama'];
    $_SESSION['level'] = 'Admin';
    header("Location: index.php?module=beranda&pesan=Berhasil");
} else {

    header("Location: index.php?module=beranda&pesan=Gagal");
}


?>