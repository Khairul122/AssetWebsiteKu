<?php
if (empty($_GET['link'])) {
    $link = '';
} else {
    $link = $_GET['link'];
}
if (empty($_GET['aksi'])) {
    $aksi = '';
} else {
    $aksi = $_GET['aksi'];
}
switch ($link) {
    case 'akun':
        # code...
        include "incl/akun/show.php";
        break;
    case 'tambah_akun':
        # code...

        if ($aksi == "simpan") {

            include "incl/akun/aksi.php";
        } else {
            include "incl/akun/tambah.php";
        }
        break;

    case 'edit_akun':
        # code...
        if ($aksi == "simpan") {

            include "incl/akun/aksi.php";
        } else {
            include "incl/akun/edit.php";
        }
        break;
    case 'hapus_akun':
        # code...
        $no_akun = $_GET['no_akun'];
        include "incl/akun/aksi.php";
        break;

    case 'saldo_awal':
        # code...
        include "incl/saldo_awal/show.php";
        break;
    case 'tambah_saldo_awal':
        # code...
        if ($aksi == "simpan") {

            include "incl/saldo_awal/aksi.php";
        } else {
            include "incl/saldo_awal/tambah.php";
        }
        break;
    case 'edit_saldo_awal':
        # code...
        if ($aksi == "simpan") {

            include "incl/saldo_awal/aksi.php";
        } else {
            include "incl/saldo_awal/edit.php";
        }
        break;
    case 'hapus_saldo_awal':
        # code...
        $id_saldo_awal = $_GET['id_saldo_awal'];
        include "incl/saldo_awal/aksi.php";
        break;

    case 'jurnal_umum':
        # code...
        include "incl/jurnal_umum/show.php";
        break;
    case 'tambah_jurnal_umum':
        # code...
        if ($aksi == "simpan") {

            include "incl/jurnal_umum/aksi.php";
        } else {
            include "incl/jurnal_umum/tambah.php";
        }
        break;

    case 'selesai_jurnal':
        # code...
        $no_jurnal = $_GET['no_jurnal'];
        include "incl/jurnal_umum/aksi.php";
        break;
    case 'hapus_jurnal_umum_':
        # code...
        $id_jurnal_umum = $_GET['id_jurnal_umum'];
        include "incl/jurnal_umum/aksi.php";
        break;
    case 'hapus_jurnal_umum':
        # code...
        $id_jurnal_umum = $_GET['id_jurnal_umum'];
        include "incl/jurnal_umum/aksi.php";
        break;

    case 'buku_besar':
        # code...
        include "incl/buku_besar/show.php";
        break;
    case 'tambah_buku_besar':
        # code...
        if ($aksi == "simpan") {

            include "incl/buku_besar/aksi.php";
        } else {
            include "incl/buku_besar/tambah.php";
        }
        break;
    case 'edit_buku_besar':
        # code...
        if ($aksi == "simpan") {

            include "incl/buku_besar/aksi.php";
        } else {
            include "incl/buku_besar/edit.php";
        }
        break;
    case 'hapus_buku_besar':
        # code...
        $id_buku_besar = $_GET['id_buku_besar'];
        include "incl/buku_besar/aksi.php";
        break;

    case 'jurnal_penyesuaian':
        # code...
        include "incl/jurnal_penyesuaian/show.php";
        break;
    case 'tambah_jurnal_penyesuaian':
        # code...
        if ($aksi == "simpan") {

            include "incl/jurnal_penyesuaian/aksi.php";
        } else {
            include "incl/jurnal_penyesuaian/tambah.php";
        }
        break;
    case 'selesai_jurnal_penyesuaian':
        # code...
        $no_jurnal = $_GET['no_jurnal'];
        include "incl/jurnal_penyesuaian/aksi.php";
        break;
    case 'hapus_jurnal_penyesuaian':
        # code...
        $id_jurnal_penyesuaian = $_GET['id_jurnal_penyesuaian'];
        include "incl/jurnal_penyesuaian/aksi.php";
        break;
    case 'hapus_jurnal_penyesuaian_':
        # code...
        $id_jurnal_penyesuaian = $_GET['id_jurnal_penyesuaian'];
        include "incl/jurnal_penyesuaian/aksi.php";
        break;


    case 'user':
        # code...
        include "incl/user/show.php";
        break;
    case 'tambah_user':
        # code...
        if ($aksi == "simpan") {

            include "incl/user/aksi.php";
        } else {
            include "incl/user/tambah.php";
        }
        break;
    case 'edit_user':
        # code...
        if ($aksi == "simpan") {

            include "incl/user/aksi.php";
        } else {
            include "incl/user/edit.php";
        }
        break;
    case 'hapus_user':
        # code...
        $id_user = $_GET['id_user'];
        include "incl/user/aksi.php";
        break;

    case 'login':
        # code...
        include "login.php";
        break;
    case 'proses_login':
        # code...
        include "proses_login.php";
        break;

    case 'logout':
        # code...
        include "logout.php";
        break;
    case 'laporan':
        # code...
        include "laporan.php";
        break;
    case 'barang':
        # code...
        include "incl/barang/show.php";

        break;
    case 'tambah_barang':
        # code...
        if ($aksi == "simpan") {

            include "incl/barang/aksi.php";
        } else {
            include "incl/barang/tambah.php";
        }
        break;
    case 'edit_barang':
        # code...
        if ($aksi == "simpan") {

            include "incl/barang/aksi.php";
        } else {
            include "incl/barang/edit.php";
        }
        break;
    case 'hapus_barang':
        # code...
        $id_barang = $_GET['id_barang'];
        include "incl/barang/aksi.php";
        break;
    case 'pembelian':
        # code...
        include "incl/pembelian/show.php";
        break;
    case 'tambah_pembelian':
        # code...
        if ($aksi == "simpan") {

            include "incl/pembelian/aksi.php";
        } else {
            include "incl/pembelian/tambah.php";
        }
        break;
    case 'hapus_pembelian':
        # code...
        $id_pembelian = $_GET['id_pembelian'];
        include "incl/pembelian/aksi.php";
        break;
    case 'hapus_pembelian_':
        # code...
        $id_pembelian = $_GET['id_pembelian'];
        include "incl/pembelian/aksi.php";
        break;
    case 'selesai_pembelian':
        # code...
        $no_faktur = $_GET['no_faktur'];
        include "incl/pembelian/aksi.php";
        break;

    case 'penjualan':
        # code...
        include "incl/penjualan/show.php";
        break;
    case 'tambah_penjualan':
        # code...
        if ($aksi == "simpan") {

            include "incl/penjualan/aksi.php";
        } else {
            include "incl/penjualan/tambah.php";
        }
        break;
    case 'hapus_penjualan':
        # code...
        $id_penjualan = $_GET['id_penjualan'];
        include "incl/penjualan/aksi.php";
        break;
    case 'hapus_penjualan_':
        # code...
        $id_penjualan = $_GET['id_penjualan'];
        include "incl/penjualan/aksi.php";
        break;
    case 'selesai_penjualan':
        # code...
        $no_faktur = $_GET['no_faktur'];
        include "incl/penjualan/aksi.php";
        break;
    case 'tarik_penjualan':
        # code...
        include "incl/penjualan/tarik.php";
        break;

    default:
        # code...
        include "incl/dashboard.php";
        break;


}

?>