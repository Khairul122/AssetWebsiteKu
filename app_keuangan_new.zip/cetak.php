<?php
$jenis = $_POST['jenis'];
switch ($jenis) {
    case '1':
        # code...
        include "laporan_buku_besar.php";
        break;
    case '2':
        # code...
        include "laporan_neraca_saldo.php";
        break;
    case '3':
        # code...
        include "laporan_neraca_lajur.php";
        break;
    case '4':
        # code...
        include "laporan_laba_rugi.php";
        break;
    case '5':
        # code...
        include "laporan_neraca.php";
        break;

    default:
        # code...
        break;
}
?>